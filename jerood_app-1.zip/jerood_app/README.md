# تطبيق جيرود (Jerood Mobile App) 🇸🇾

تطبيق مدينة جيرود الرسمي بنمط Apple iOS (Cupertino) وتكامل مع Google Sheets:
دليل أدوار المياه، الصيدليات المناوبة، أرقام الطوارئ، والإعلانات — بالكامل
بالعربية واتجاه RTL.

## هيكل المشروع

```
lib/
├── main.dart                     نقطة الدخول + إعداد CupertinoApp
├── constants.dart                الثوابت (اسم التطبيق، معرّف الشيت، الألوان)
├── models/                       نماذج البيانات (Pharmacy, WaterSchedule, ...)
├── services/
│   ├── sheets_service.dart       جلب البيانات من Google Sheets (GViz) + كاش
│   ├── storage_service.dart      تخزين محلي (SharedPreferences)
│   ├── notification_service.dart إشعارات أدوار المياه المحلية
│   └── analytics_service.dart    Firebase Analytics (اختياري، آمن بدونه)
├── theme/cupertino_theme.dart    السمة البصرية الفاتحة/الداكنة
├── widgets/                      عناصر مشتركة (IosCard, AdBannerWidget)
└── screens/
    ├── home_screen.dart          الشاشة الرئيسية (تبويبات + تبويب المياه)
    ├── pharmacies_screen.dart    شاشة الصيدليات المناوبة
    ├── emergency_screen.dart     شاشة أرقام الطوارئ
    └── settings_screen.dart      شاشة الإعدادات

.github/workflows/build_apk.yml   بناء APK تلقائياً عبر GitHub Actions
```

## التشغيل السريع

> إن لم يكن المشروع يملك بعد مجلدي `android/` و`ios/` (هذا الرفع يحتوي
> كود Dart والإعدادات فقط)، شغّل أولاً `flutter create .` داخل مجلد
> المشروع لتوليدهما، ثم:

```bash
flutter pub get
flutter run
flutter build apk --release
```

سير العمل في `.github/workflows/build_apk.yml` يبني APK تلقائياً عند كل
push إلى main/master، ويرفعه كمرفق (Artifact) في GitHub Actions.

## ملاحظات ونقاط يُستحسن التحقق منها

- **ترتيب أعمدة الشيت**: دوال `fromRow` في `lib/models/` تفترض ترتيباً
  منطقياً للأعمدة (مثلاً Pharmacies: الاسم، العنوان، المناوبة، الهاتف).
  إن كان ترتيب شيتك الفعلي مختلفاً، عدّل الدالة المعنية فقط.
- **Firebase Analytics**: يعمل التطبيق بشكل طبيعي بدون أي إعداد لـ
  Firebase (تُعطَّل التحليلات بصمت). لتفعيلها فعلياً، شغّل
  `flutterfire configure` لإنشاء `firebase_options.dart` وملفات الإعداد
  الخاصة بكل منصة.
- **خط Cairo**: مُستخدم في `settings_screen.dart` كاسم خط، لكنه غير مرفق
  كملف أصول (asset). بدون إضافته في `pubspec.yaml` ضمن قسم `fonts:`
  سيستخدم النظام الخط الافتراضي تلقائياً دون أي خطأ في البناء.
- **أيقونات التبويبات**: إن أظهر `flutter analyze` خطأً بسيطاً حول اسم
  أيقونة من `CupertinoIcons`، يمكن استبدالها بسهولة بأي أيقونة أخرى من
  نفس المكتبة.

---
طُوّر من قِبل هيثم البوشي
